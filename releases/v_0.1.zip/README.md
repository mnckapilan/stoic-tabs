# stoic-tabs
A Chrome extension that displays a stoic quote when opening a new tab
